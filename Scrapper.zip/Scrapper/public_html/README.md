

To run so that you can scrap and generate data needed
"node app %search_term% %limit% " , of course without '%' and '"'

Finally wait for completion then,
To export data to csv :
 'node csv' without emails,because it is way faster without scrapping the emails and gets 100% of the data
 or 
 'node more' to scrap  each individual website,it uses regex blind search to get the emails,so some may not be captured,and it might
 be really slow if you are scrapping large data or  you have slow internet connection


*Data is stored in jsonFiles folder*
*csv in csv folder


