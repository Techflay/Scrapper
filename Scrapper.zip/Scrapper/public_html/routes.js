var path = require('path');
var fs = require('fs');
var cheerio = require('cheerio');
var path = require('path').dirname(require.main.filename);
var jsonfile = require('jsonfile');
var async = require("async");

'use strict';

var request = require('request');

module.exports = function (app, address,args) {

    var search_term = args[0]; 
    var pages = [];
    var count = 0;
    var oCount = 0;
    
    var limit = args[1];
    var max = limit;
    
    if(limit == null || limit == ""){
        limit = 1000;
    }
    console.log("Generating data for search term "+search_term+" limit "+limit);
    
    var no_of_loops = (limit/30)+1; //Because each page has minimum 30 valid links
    
    for(var i = 1; i <= (no_of_loops);i++){
        pages.push(i);
    }
    
    //Write counter for expected pages (loops)
    var count_file = path + '/jsonFiles/count.json';
    jsonfile.writeFile(count_file, {count:no_of_loops}, function (err) {
        if(err){
              console.error(err);
        }
       
    });
    
    //To keep track of current search term
    var tracker_file = path + '/jsonFiles/tracker.json';
    jsonfile.writeFile(tracker_file, {search_term:search_term}, function (err) {
        if(err){
            console.error(err);
        }
    });
        
  
    async.eachSeries(pages,
        function (page, callback) {
            var url = "";
            if(page == 1){
                 url = "http://www.europages.co.uk/companies/" + search_term + ".html";
            }else{
                 url = "http://www.europages.co.uk/companies/pg-" + page + "/"+ search_term +".html";
            }
            console.log(url);
            getData(url,page,max);
           async.setImmediate(function () {
                callback();
            });
        },
        function (err) {
            if(err){
                console.log(err);
            }
           
        }
    );

    function getData(url,page,max) {
        
        
        var companyArray = [];

        request(url, function (err, res, body) {

            if (!err && res.statusCode === 200) {
                var $ = cheerio.load(body);

                var ul = $('#contentEcard ul').first(); //Retrieve the list
                
                $(ul).each(function () {
                  $(this).find('li').each(function () {//Get all the list items
                        
                    var $li = $(this);

                    var div = $li.find(".main-title");
                    var a = $(div).find('a.company-name');

                    var companyName = a.attr('title');
                    var website_link = a.attr('href');

                    if (companyName != undefined) {
                         // console.log(companyName);
                         if(count < max){
                             count++;
                             
                          getCompanyData(website_link,companyName, function (result) {
                            companyArray.push(result);
                            
                            oCount++;
                             console.log(" "+oCount+". Data For > "+companyName);
                             //write into temp json files
                            var jFile= path + '/jsonFiles/file'+page+'.json';
                            jsonfile.writeFileSync(jFile, companyArray);
                            
                        });
                       }
                       }else{
                           //console.log("udefined "+companyName);
                       }
                    });
                });
            }
            
        });
    }

    function getCompanyData(link,companyName, callback) { //If you click a company link,this is the page
        
        if (link != undefined && link != null ) {
            var data = {};
            
            request(link, function (err, res, body) {
            if(err){
               console.log(err);   
            }else{
                var $ = cheerio.load(body);
                $('.image > a').each(function (index) {
                   
                    var company_url = $(this).attr('href'); 
                    if(company_url != null || company_url != undefined ){
                        data["website"] = company_url; 
                    }else{
                          data["website"] = "";
                    }
                    
                });
                
                    data["company_url"] = link;
                    
                     var address = $("[itemprop=addressLocality]").find("pre").text();
                     if(address != null || address != undefined ){
                       data["address"] = address;
                     }else{
                          data["address"] = "";
                     }
                     
                    var country = $("[itemprop=addressCountry]").find(".upper").text();  
                    if(country != null || country != undefined ){
                       data["country"] = country;
                    }else{
                         data["country"] = "";
                    }
                    data["company_name"] = companyName;
                    callback(data);
                }
            });
            
        }
    }
    process.on('exit', function () {
        console.log("All done generating data !");
    });
};
