var Crawler = require("simplecrawler");
var cheerio = require('cheerio');
var async = require('async');
var json2csv = require('json2csv');
var jsonfile = require('jsonfile');
var path = require('path').dirname(require.main.filename);
var fs = require('fs');
var operations = [];
var dataArray = [];
var count = 0;
var syncCount = 0;

 colors = {
 Reset: "\x1b[0m",
 Bright: "\x1b[1m",
 Dim: "\x1b[2m",
 Underscore: "\x1b[4m",
 Blink: "\x1b[5m",
 Reverse: "\x1b[7m",
 Hidden: "\x1b[8m",
 fg: {
  Black: "\x1b[30m",
  Red: "\x1b[31m",
  Green: "\x1b[32m",
  Blue: "\x1b[34m",
  Cyan: "\x1b[36m",
  White: "\x1b[37m",
 },
 bg: {
  Black: "\x1b[40m",
  Red: "\x1b[41m",
  Blue: "\x1b[44m",
  Cyan: "\x1b[46m",
  White: "\x1b[47m",
 }
};

module.exports = function (search_term,data,start) {
    
    count = start;
    
    if(data != null && data != undefined){
      function myFunc(arg) {
        getCrawling(arg.index,arg.data,function(result){
           setTimeout(function(){
               console.log("Just crawled");
           }, 1000 );

       });
     }
     
        for(var i = start; i < data.length; i++){
            var myData = {
                index:i,
                data:data
            };
          setTimeout(myFunc, 100,myData );
        }
        
        function getCrawling(i,data,callback){
            
          var url = data[i].website;
         
          if(url != null && url != undefined && url != ""){
            var url = url.trim();
          
            if (validateUrl(url)){ 
                //console.log(url)
                var crawler = Crawler(url);
                crawler.interval = 100; // 1 seconds interval so togive breathing space
                crawler.maxDepth = 2;
               crawler.useProxy= true;
                crawler.proxyHostname = "172.16.0.1";
                crawler.proxyPort = 8080;
                crawler.proxyUser = null;
                crawler.proxyPass = null;
               // crawler.timeout = 300000;
            
           
            
             crawler.addFetchCondition(function(queueItem, referrerQueueItem, callback) {
                callback(null, !queueItem.path.match(/([a-z\-_0-9\/\:\.]*\.(jpg|jpeg|png|gif|css|js|pdf|svg|mp4|mp3|mkv|avi))/i));
            });
           
            crawler.on("fetchcomplete", function(queueItem, responseBuffer, response) {
               var url = queueItem.url;
               
               console.log(colors.bg.Black, colors.fg.White ,url)
                var $ = cheerio.load(responseBuffer.toString("utf8"));
               // console.log($.text())
                //
                 var link = $('a[href^="mailto:"]').attr("href");
                 if(link != undefined && link != null){
                     
                      var email = link.substr(7,link.length);
                       if(checkValid(email) && email.length < 45){
                       //  console.log("url: "+url+"    --- email: "+email);
                         data[i].email = email;
                          dataArray.push(data[i]);
                          count ++;
                          var varCount = count + start*100;
                         console.log(colors.bg.Black, colors.fg.Cyan , "count: "+count+ " "+ data[i].email);
                         crawler.stop();
                      
                         //exportToCsv(search_term, data); 

                         var file_path = path +"/jsonFiles/"+search_term+".json";
                         jsonfile.writeFile(file_path, dataArray, function (err) {
                           if(err){
                              
                              console.error(err);
                           }
                        });
                         callback("Finished "+i);
                        return;
                  }

                 }else{
                     var email = findEmailAddresses ($.text()); 
                     
                     if(email != undefined && email != null && checkValid(email)){
                       // console.log("url: "+url+"    --- email from regex "+email);
                        data[i].email = email
                        dataArray.push(data[i]);
                        // console.log(data[i]);
                         count ++;
                          var varCount = count + start*100;
                          console.log(colors.bg.Black, colors.fg.Cyan ,"count: "+count+ " "+ data[i].email);
                          var file_path = path +"/jsonFiles/"+search_term+".json";
                            jsonfile.writeFile(file_path, dataArray, function (err) {
                                if(err){
                                   console.error(err);
                                }
                           });
                       //exportToCsv(search_term, email);
                      
                         crawler.stop();
                        callback("Finished "+i);
                        return;
                     }else{
                          //console.log("invalid "+email+" ----- url "+url);
                     }
                 }
            
            });
            
             crawler.start();
              }else{
                  // console.log("url: "+url+" is NOT VALID URL");
             }
           }else{
                 //console.log(url)
               // exportToCsv(search_term, data);
           }
         }
    
    }
}
function validateUrl(url){
    var regex = new RegExp("^(http[s]?:\\/\\/(www\\.)?|ftp:\\/\\/(www\\.)?|www\\.){1}([0-9A-Za-z-\\.@:%_\+~#=]+)+((\\.[a-zA-Z]{2,3})+)(/(.)*)?(\\?(.)*)?");
    if(regex.test(url)){
    //  console.log("Successful match");
      return true;
    }else{
      //console.log("No match"); 
      return false;
    }
}
function findEmailAddresses(StrObj) {
        var separateEmailsBy = ", ";
        var email = "<none>"; // if no match, use this
        var emailsArray = StrObj.match(/([a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9._-]+)/gi);
        if (emailsArray) {
            email = "";
            for (var i = 0; i < emailsArray.length; i++) {
                if(emailsArray[i].length < 45){
                    if (i != 0) email += separateEmailsBy;
                    email += emailsArray[i];
                }
            }
        }
        return email;
}

function validateEmail(email) {
    var chrbeforAt = email.substr(0, email.indexOf('@'));
    if (!($.trim(email).length > 127)) {
        if (chrbeforAt.length >= 2) {
            var re = /^(([^<>()[\]{}'^?\\.,!|//#%*-+=&;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/;
            //var re = /[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/;
            return re.test(email);
        } else {
            return false;
        }
    } else {
        return false;
    }
}
function validateEmail(email) {
var chrbeforAt = email.substr(0, email.indexOf('@'));
if (!((email).length > 127)) {
    if (chrbeforAt.length >= 2) {
        var re = /^(([^<>()[\]{}'^?\\.,!|//#%*-+=&;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/;
        //var re = /[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/;
        return re.test(email);
    } else {
        return false;
    }
} else {
    return false;
}
}
function checkValid(text){
   
    var pattern = /^[a-zA-Z]/;
    var result = pattern.test(text);
    var invalids =  (/^[%*?;:]/).test(text);
    var part  = (/^[0-9]/).test(text);
    
    if (result === true && invalids === false && part === false) {
       // console.log(pattern, "pattern did match !");
        return true;
    } else {
      //  console.log(text +" url "+url);
        //console.log(pattern, " pattern did NOT match");
        return false;

    }
}  
function extractEmails (text){
    return text.match(/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/);
}
function exportToCsv(search_term, data) {
   // if(data.email != null && data.email != "" && data.email != undefined){
    //console.log(data);

      var fields = ['company_name','website','country','address','company_url','email' ];
       var fieldNames = ['Company Name', 'Website','Country','Address','Europage URL','Email'];
     
        var opts = {
         data: data,
         fieldNames:fieldNames,
         fields: fields
     };
     
     var csv = json2csv(opts);
     fs.writeFile("csv/"+search_term + ".csv", csv, function (err) {
         if (err)
             throw err;
      //console.log("Writing CSV file for search term '" + search_term );
     });
  
//}
}