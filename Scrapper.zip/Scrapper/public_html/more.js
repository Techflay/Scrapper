var json2csv = require('json2csv');
var jsonfile = require('jsonfile');
var path = require('path').dirname(require.main.filename);
var fs = require('fs');
var async = require("async");

var args = process.argv.slice(2);
var start = args[0];
var dataArray = [];
var exists = 0;
var d_exists = 0;

if(start == null || start == undefined){
    console.log("Select valid start val, selected default to 1");
    start = 0;
}else{
    console.log("Starting at "+start);
}

//To get the search term
var tracker_file = path + '/jsonFiles/tracker.json';

jsonfile.readFile(tracker_file, function (err, obj) {
    if(err){
         console.log(err);
    }
    //Get the counter -- To determine last file
    var count_file = path + '/jsonFiles/count.json';
    
    jsonfile.readFile(count_file, function (err2, obj2) {
        if(err){
             console.log(err2);
        }
       getJsonData(obj.search_term,obj2.count);
      
    });

});

//Fetch data from the json files
function getJsonData(searchTerm,count){
    var files = [];
    var newStart = start * 7;
    var oldStart = 1;
    
    if(start > 1){
         oldStart = ((start - 1) * 7) + 1;
    }
    console.log("count: "+count+" oldStart "+oldStart+" newStart "+newStart);
    for(var i = 1; i <= count; i++){
        var file_path = path+"/jsonFiles/file"+i+".json";
        
        try {
            stats = fs.statSync(file_path);
            //console.log("File exists."); 
            files.push("file"+i+".json");
            
            var obj = jsonfile.readFileSync(file_path);
            dataArray.push(obj);
            exists++;
          }catch (e) {
              d_exists++;
           //console.log("File does not exist.");
            console.log(file_path);
          }finally{
             
              if(i > (count-1)){
                    callCrawl(searchTerm,start);
              }
          }
        
    }
    
    
    //Read the files one by one
   
   /* async.eachSeries(files,
        function (file, callback) {
            var file_path = path + '/jsonFiles/'+file;
            
            async.setImmediate(function () {
                callback();
            });
        },
        function (err) {
            if(err){
               console.log(err); 
            }
           
        }
                
    );*/
}
function callCrawl(searchTerm,start){
     var allArray = [];
     for(var i = 0; i < dataArray.length; i++){
         var tempArr = dataArray[i];
         for(var j = 0; j < tempArr.length; j++){
             var obj = tempArr[j];
             allArray.push(obj);
         }
     }
    
     console.log("Expecting data of size : "+allArray.length);
      require('./crawl')(searchTerm,allArray,start);
     /* var file_path = path +"/jsonFiles/"+searchTerm+".json";
        jsonfile.writeFile(file_path, allArray, function (err) {
          if(err){
             console.error(err);
          }
       });*/
    
}
  process.on('exit', function () {
        console.log("All done creating CSV file !");
 });