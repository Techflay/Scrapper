var json2csv = require('json2csv');
var jsonfile = require('jsonfile');
var path = require('path').dirname(require.main.filename);
var fs = require('fs');
var async = require("async");

//To get the search term
var tracker_file = path + '/jsonFiles/tracker.json';

jsonfile.readFile(tracker_file, function (err, obj) {
    if(err){
         console.log(err);
    }
    //Get the counter -- To determine last file
    var count_file = path + '/jsonFiles/count.json';
    
    jsonfile.readFile(count_file, function (err2, obj2) {
        if(err){
             console.log(err2);
        }
       getData(obj.search_term,obj2.count);
    });    
});

function getData(searchTerm,count){
    
    console.log("search "+searchTerm+" count "+count);
    for(var i = 1; i <= count; i++){
       var file_path = path+"/jsonFiles/file"+i+".json";
        try {
            stats = fs.statSync(file_path);
           
            files.push("file"+j+".json");
             console.log("Setting for "+j);
            jsonfile.readFile(file_path, function (err, obj) { 
                if(err){
                     console.log(err);
                }
               
                console.log(obj);
                setOneJsonFile(searchTerm,obj);
            }); 

          }catch (e) {
            //console.log("File does not exist."+i);
            //console.log(file_path);
          }
      }
}
function setOneJsonFile(searchTerm,dataArray){
    var file_path = path +"/jsonFiles/"+searchTerm+".json";
    jsonfile.writeFile(file_path, dataArray,{flag:"a"}, function (err) {
        if(err){
           console.error(err);
        }
   });
}