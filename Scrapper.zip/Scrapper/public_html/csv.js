var json2csv = require('json2csv');
var jsonfile = require('jsonfile');
var path = require('path').dirname(require.main.filename);
var fs = require('fs');
async = require("async");


//To get the search term
var tracker_file = path + '/jsonFiles/tracker.json';

jsonfile.readFile(tracker_file, function (err, obj) {
    if(err){
         console.log(err);
    }
    
    //Get the counter -- To determine last file
    var count_file = path + '/jsonFiles/count.json';
    
    jsonfile.readFile(count_file, function (err2, obj2) {
        if(err){
             console.log(err2);
        }
      
       getJsonData(obj.search_term,obj2.count);
    });
    
});

//Fetch data from the json files
function getJsonData(searchTerm,count){
    var files = [];
    for(var i = 1; i <= count; i++){
        var file_path =  path +"jsonFiles/file"+i+".json";
        try {
            stats = fs.statSync(file_path);
           // console.log("File exists."); 
            files.push("file"+i+".json");
          }catch (e) {
            console.log("File does not exist.");
            console.log(file_path);
          }
        
    }
    
    //Read the files one by one
    async.each(files,
        function (file, callback) {
            var file_path = path + '/jsonFiles/'+file;
            jsonfile.readFile(file_path, function (err, obj) { 
                if(err){
                     console.log(err);
                }
                exportToCsv(searchTerm, obj);
            }); 
            callback();
        },
        function (err) {
            if(err){
               console.log(err); 
            }
           
        }
                
    );
  
}
 
function exportToCsv(search_term, data) {

     var fields = ['company_name','website','country','address','company_url' ];
     var fieldNames = ['Company Name', 'Website','Country','Address','Europage URL'];
     
     var opts = {
         data: data,
         fieldNames:fieldNames,
         fields: fields
     };
     var csv = json2csv(opts);
     fs.appendFile("csv/"+search_term + ".csv", csv, function (err) {
         if (err)
             throw err;
         console.log("Writing CSV file for search term '" + search_term );
     });
  
 }
  process.on('exit', function () {
        console.log("All done creating CSV file !");
 });