var json2csv = require('json2csv');
var jsonfile = require('jsonfile');
var path = require('path').dirname(require.main.filename);
var fs = require('fs');
var async = require("async");

//To get the search term
var tracker_file = path + '/jsonFiles/tracker.json';

jsonfile.readFile(tracker_file, function (err, obj) {
    if(err){
         console.log(err);
    }
    
    var file_path = path +"/jsonFiles/"+obj.search_term+".json";
    jsonfile.readFile(file_path, function (err, obj2) { 
        if(err){
             console.log(err);
        }
        exportToCsv(obj.search_term, obj2);
    });     
    
});

 
function exportToCsv(search_term, data) {
   // if(data.email != null && data.email != "" && data.email != undefined){
    //console.log(data);

      var fields = ['company_name','website','country','address','company_url','email' ];
       var fieldNames = ['Company Name', 'Website','Country','Address','Europage URL','Email'];
     
       
     
     if (fs.existsSync(path+"/csv/"+search_term + ".csv")) {
          var opts = {
         data: data
        };

        var csv = json2csv(opts);
        console.log("Appending file ");
        fs.appendFile("csv/"+search_term + ".csv", csv, function (err) {
         if (err)
             throw err;
      //console.log("Writing CSV file for search term '" + search_term );
      });
     
    }else{
         var opts = {
         data: data,
         fieldNames:fieldNames,
         fields: fields
        };

        var csv = json2csv(opts);
        console.log("Creating file ");
         fs.writeFile("csv/"+search_term + ".csv", csv, function (err) {
         if (err)
             throw err;
      //console.log("Writing CSV file for search term '" + search_term );
     });
    }
    
  
//}
}
  process.on('exit', function () {
        console.log("All done creating CSV file !");
 });